---
name: teams_notify
description: Send a Microsoft Teams notification via the internal teams-notifier service. Use for actionable alerts (deployment/job/task failures, etc.). Write action — not read-only.
---

# teams_notify

Sends a Microsoft Teams message through the internal `teams-notifier` service
(`POST {NOTIFIER_URL}`). Backed by the `teams-notifier-mcp` MCP server (a small
Python FastMCP tool). GoClaw registers it with the `teams_` prefix, so the agent
calls it as **`teams_notify`**.

## When to use

- A deployment, job, pipeline, or task **failed** and a human must act
  ("deployment to prd failed after 3 retries").
- An operational event worth paging a channel about (errors, outages, alert
  thresholds crossed).
- The user explicitly asks to notify a Teams channel.

Do **not** use it for read-only / inspection / Q&A tasks, or for status someone
asked for interactively. Notifications are high-signal — see "Anti-spam rules".

## How to invoke

```
use_skill(skill="teams_notify",
          title="Model gru-v2 deploy failed",
          body="Deployment to prd failed after 3 retries.",
          team="Advanced Analytics",
          channel="SCAM-NOTIFS",
          status="error",
          action={"title": "View Logs", "url": "https://grafana.k8s-prd.bankingcircle.net"},
          facts=[{"title": "Environment", "value": "prd"}])
```

Minimal call (required fields only):

```
use_skill(skill="teams_notify",
          title="Backup job completed",
          body="Nightly backup finished successfully.",
          team="Advanced Analytics",
          channel="SCAM-NOTIFS")
```

## Parameters

| Name | Type | Required | Description |
|---|---|---|---|
| `title` | string | **yes** | Short one-line notification title. |
| `body` | string | **yes** | Concise body text. Put structured detail in `facts`, not a long `body`. |
| `team` | string | **yes** | Target Teams team name, e.g. `"Advanced Analytics"`. |
| `channel` | string | **yes** | Target Teams channel name, e.g. `"SCAM-NOTIFS"`. |
| `status` | string | no | One of `info`, `success`, `warning`, `error`. Prefixes the title. |
| `action` | object | no | `{"title": <button label>, "url": <button url>}` — appended as a Details link. |
| `facts` | array | no | `[{"title": <label>, "value": <value>}]` — appended to the body as key/value lines. Prefer an `Environment` (dev/stg/prd) fact when known. |

## What it returns

A JSON object:

```
{
  "upstream_status": 200,              // HTTP status from the notifier
  "response": { "status": "ok", ... }  // notifier's response body
}
```

- `upstream_status` **200** (and `response.status == "ok"`) = delivered.
- Non-200 = the notifier rejected it. Report the `response` to the user; do not
  retry more than once with identical arguments.

## Common pitfalls

- **Channel is chosen by YOU, not the tool** — there is no server-side default.
  Use the channel from the agent's system-prompt default (or the user's explicit
  request). If the prompt sets a default (e.g. `SCAM-NOTIFS`), use it unless the
  user says otherwise.
- **Wrong team/channel name** → the notifier returns non-200 or the message
  lands in the wrong place. Confirm names if unsure.
- **`status` must be exact** — only `info | success | warning | error`.
- **Missing required field** — `title`, `body`, `team`, `channel` are mandatory;
  omitting one fails the call.

## Anti-spam / safety rules

1. Send **AT MOST one** notification per incident; do not re-notify for the same
   event. If unsure whether you already notified, do not send again.
2. **NEVER** put secrets, tokens, passwords, kubeconfig contents, or secret
   values into `title`, `body`, `action`, or `facts`. Names and namespaces are
   fine; values are not.
3. This skill **sends a message** (a write action). It does not read or modify
   cluster state. Send only when a human genuinely needs to act.
