---
name: k8s_pods_get
description: Get a Kubernetes Pod in the current or provided namespace with the provided name. Read-only.
---

# k8s_pods_get

Fetches detailed information about a single Pod. Equivalent to
`kubectl get pod <name> -n <namespace> -o yaml`. Backed by the
kubernetes-mcp-server `pods_get` tool.

## When to use

- User asks about a specific pod by name ("what's the status of
  nginx-abc123", "describe pod X").
- Before calling `k8s_pods_log`, to confirm the pod exists and see its
  container statuses.
- After `k8s_pods_list` identifies an unhealthy pod, to get full details.

## How to invoke

```
use_skill(skill="k8s_pods_get", name="coredns-ccb96694c-9cmxz", namespace="kube-system")
use_skill(skill="k8s_pods_get", name="nginx-abc123")  # uses default namespace
```

## Parameters

| Name | Type | Required | Description |
|---|---|---|---|
| `name` | string | **yes** | Exact pod name (including the random suffix for Deployment-managed pods). Get from `k8s_pods_list` if unsure. |
| `namespace` | string | no | Namespace the pod lives in. If omitted, uses the configured default namespace. |

## What it returns

The full Pod object as YAML/JSON, including:
- `metadata` — name, namespace, labels, annotations, ownerReferences
- `spec` — containers, volumes, nodeSelector, tolerations
- `status` — phase (Pending/Running/Succeeded/Failed/Unknown),
  conditions, containerStatuses (with restart counts and last state),
  podIP, hostIP, startTime

## Common pitfalls

- **"Pod not found"** — the name is wrong or the pod was deleted
  between `pods_list` and this call. Re-run `k8s_pods_list` to get the
  current name.
- **Wrong namespace** — if you omit `namespace` and the pod isn't in
  the default, you'll get not-found. Always pass namespace when known.
- **Huge YAML output** — pod specs can be hundreds of lines. Summarize
  key fields (status, restart counts, container images) when responding
  to the user.

## Read-only safety

This skill only READS pod state. It never modifies, restarts, or
deletes the pod. Safe to call freely.
