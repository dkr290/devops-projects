---
name: k8s_projects_list
description: List all the OpenShift projects in the current cluster. On plain Kubernetes (non-OpenShift) this will return an error or empty result. Read-only.
---

# k8s_projects_list

Lists OpenShift Projects. OpenShift Projects are roughly equivalent to
Kubernetes Namespaces but with additional metadata. Backed by the
kubernetes-mcp-server `projects_list` tool.

## When to use

- **Only on OpenShift clusters.** On plain Kubernetes (k3s, kind, EKS,
  GKE, AKS, etc.), this skill will return an error or empty list because
  the `project.openshift.io` API doesn't exist.
- User asks "list projects", "show OpenShift projects" — and you've
  confirmed the cluster is OpenShift.

## How to invoke

```
use_skill(skill="k8s_projects_list")
```

## Parameters

This skill takes **no parameters**.

## What it returns

On OpenShift: a table of projects (similar to namespace listing).
On plain Kubernetes: an error such as "the server could not find the
requested resource" or an empty list.

## Common pitfalls

- **Do NOT call this on a plain Kubernetes cluster** — it will fail.
  Use `k8s_namespaces_list` instead. The output of
  `k8s_namespaces_list` IS the project list equivalent.
- **Detecting OpenShift vs plain Kubernetes** — call
  `k8s_resources_list` with `apiVersion=config.openshift.io, kind=ClusterVersion`.
  If it returns a result, you're on OpenShift; if it errors, plain
  Kubernetes.

## Read-only safety

This skill only READS project metadata. It never modifies the cluster.
Safe to call, but pointless on non-OpenShift clusters.
