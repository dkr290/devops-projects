---
name: k8s_nodes_log
description: Get logs from a Kubernetes node (kubelet, kube-proxy, or other system logs) via the Kubernetes API proxy to the kubelet. Read-only.
---

# k8s_nodes_log

Reads system-level logs from a Kubernetes node by going through the
Kubernetes API proxy to the kubelet. Use this for node-level issues
(kubelet crashes, kube-proxy errors, container runtime problems) — NOT
for pod-level logs (use `k8s_pods_log` for that). Backed by the
kubernetes-mcp-server `nodes_log` tool.

## When to use

- A node is `NotReady` and you need to see why the kubelet is failing.
- Pods are being evicted or failed to schedule and you suspect node-level
  issues (disk pressure, network plugin errors).
- User asks "kubelet logs on node X", "node system logs", "why is node
  X unhealthy".
- Investigating container runtime (containerd, CRI-O) errors.

## How to invoke

```
use_skill(skill="k8s_nodes_log", name="k3d-eg-operator-agent-0", query="kubelet")
use_skill(skill="k8s_nodes_log", name="k3d-eg-operator-agent-0",
          query="/var/log/kube-proxy.log", tailLines=200)
```

## Parameters

| Name | Type | Required | Description |
|---|---|---|---|
| `name` | string | **yes** | Name of the node. Get this from `k8s_resources_list` with `apiVersion=v1, kind=Node` or `k8s_nodes_top`. |
| `query` | string | **yes** | Either a service name (`"kubelet"`, `"kube-proxy"`) or an absolute file path (`"/var/log/kubelet.log"`, `"/var/log/containerd.log"`). |
| `tailLines` | integer | no | Number of lines from the end. Default 100. Use 0 for all logs (careful — can be huge). |

## What it returns

Plain-text log lines. Format depends on the service: kubelet logs use
klog format (`I0819 12:34:56.789 ...`), file-based logs use whatever
format the daemon wrote.

## Common pitfalls

- **Empty or "service not found"** — the `query` value doesn't match
  a known service or file. Try `query="kubelet"` first as a baseline.
- **Permission denied / RBAC error** — the `goclaw-k8s-viewer`
  ServiceAccount (bound to `view` ClusterRole) may NOT have permission
  to proxy to kubelet logs. If you get `Forbidden`, report this to the
  user and suggest checking RBAC — do NOT try to work around it.
- **Huge output** — never call with `tailLines=0` on a busy node.
  Start with `tailLines=100` and increase only if needed.
- **Node name must be exact** — use `k8s_resources_list` with
  `apiVersion=v1, kind=Node` to get the exact node name first.

## Read-only safety

This skill only READS log data. It never executes commands on the node,
modifies files, or changes system state. Safe to call freely, subject
to RBAC permissions.
