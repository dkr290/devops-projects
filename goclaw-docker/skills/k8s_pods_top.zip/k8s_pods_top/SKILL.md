---
name: k8s_pods_top
description: List CPU and memory consumption of Kubernetes Pods as recorded by the Kubernetes Metrics Server, across all namespaces or a specific one. Read-only.
---

# k8s_pods_top

Returns current CPU and memory usage for pods, sourced from
metrics-server. Equivalent to `kubectl top pods`. Backed by the
kubernetes-mcp-server `pods_top` tool.

## When to use

- User asks "which pods are using the most CPU/memory", "top pods",
  "pod resource usage".
- Identifying resource hogs before adjusting limits/requests.
- After `k8s_nodes_top` shows a node under pressure, to find the pods
  responsible.

## How to invoke

```
use_skill(skill="k8s_pods_top")                                       # all namespaces (default)
use_skill(skill="k8s_pods_top", namespace="production")
use_skill(skill="k8s_pods_top", name="nginx-abc123", namespace="default")
use_skill(skill="k8s_pods_top", label_selector="app=web")
use_skill(skill="k8s_pods_top", all_namespaces=false, namespace="default")
```

## Parameters

| Name | Type | Required | Description |
|---|---|---|---|
| `all_namespaces` | boolean | no | If true (default), covers all namespaces. If false, uses `namespace` (or current namespace). |
| `namespace` | string | no | Specific namespace. Only used when `all_namespaces=false`. |
| `name` | string | no | Specific pod name. Omit to get all pods in scope. |
| `label_selector` | string | no | Label selector. Only used when `name` is omitted. Pattern: `^([/_.\-A-Za-z0-9=, ()!])+$`. |

## What it returns

A table with columns: NAMESPACE, NAME, CPU(cores), MEMORY(bytes). CPU in
millicores; memory in Mi or Gi.

## Common pitfalls

- **Empty result** — metrics-server not installed or unhealthy. Check
  with `k8s_pods_list_in_namespace(namespace="kube-system")` for the
  metrics-server pod.
- **Stale data** — metrics-server refreshes every 30–60s.
- **Per-container breakdown not included** — for that level of detail,
  use `k8s_nodes_stats_summary` on the node where the pod runs.

## Read-only safety

This skill only READS metrics. It never modifies the cluster. Safe to
call freely.
