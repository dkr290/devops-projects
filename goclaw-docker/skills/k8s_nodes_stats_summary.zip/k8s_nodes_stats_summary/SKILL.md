---
name: k8s_nodes_stats_summary
description: Get detailed resource usage statistics from a Kubernetes node via the kubelet's Summary API. Includes CPU, memory, filesystem, network usage at node/pod/container level, plus PSI metrics on cgroup v2 / kernel 4.20+. Read-only.
---

# k8s_nodes_stats_summary

Returns the kubelet's Summary API output for one node — the most detailed
source of per-node resource metrics available without node-level SSH
access. Includes CPU, memory, filesystem, network, and (on cgroup v2 with
kernel 4.20+) Pressure Stall Information (PSI). Backed by the
kubernetes-mcp-server `nodes_stats_summary` tool.

## When to use

- Deep-diving on a single node's resource usage (more detail than
  `k8s_nodes_top` provides).
- Investigating disk pressure, memory pressure, or network saturation on
  a specific node.
- User asks "how is node X doing", "memory pressure on node X",
  "filesystem usage on node X".
- After `k8s_nodes_top` shows a node with high utilization, to identify
  WHICH pods/containers are consuming the resources.

## How to invoke

```
use_skill(skill="k8s_nodes_stats_summary", name="k3d-eg-operator-agent-0")
```

## Parameters

| Name | Type | Required | Description |
|---|---|---|---|
| `name` | string | **yes** | Exact node name. Get from `k8s_resources_list` (`apiVersion=v1, kind=Node`) or `k8s_nodes_top`. |

## What it returns

A JSON document with these top-level sections:
- `node` — node-level CPU, memory, filesystem, network, runtime stats
- `pods[]` — per-pod breakdown (each with per-container breakdown)
- `systemContainers[]` — kubelet, container runtime, etc.

Key fields within each section:
- `cpu.usageNanoCores`, `cpu.usageCoreNanoSeconds`
- `memory.usageBytes`, `memory.workingSetBytes`, `memory.availableBytes`
- `fs.usedBytes`, `fs.capacityBytes`, `fs.availableBytes`
- `network.rxBytes`, `network.txBytes`, plus per-interface stats
- `psi` (on supported kernels) — `some`/`full` stall percentages for
  CPU, memory, IO. See
  https://kubernetes.io/docs/reference/instrumentation/understand-psi-metrics/

## Common pitfalls

- **Large JSON output** — this is the most verbose skill in the set.
  Summarize key metrics for the user; do NOT paste the entire JSON
  unless asked.
- **RBAC `Forbidden`** — kubelet stats requires `nodes/stats` permission
  which the `view` ClusterRole may not grant. If you get Forbidden,
  report it to the user.
- **Node name exact match** — like all node-scoped calls.
- **Missing PSI section** — normal on cgroup v1 or older kernels.

## Read-only safety

This skill only READS metrics. It never modifies the node. Safe to call
freely, subject to RBAC.
