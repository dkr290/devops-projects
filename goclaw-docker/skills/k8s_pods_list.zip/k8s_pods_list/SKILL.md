---
name: k8s_pods_list
description: List all the Kubernetes pods in the current cluster from all namespaces. Read-only.
---

# k8s_pods_list

Lists every Pod across all namespaces. Equivalent to
`kubectl get pods -A`. Backed by the kubernetes-mcp-server `pods_list`
tool.

## When to use

- User asks "list pods", "show all pods", "what's running", "any pods
  failing".
- First step in almost any workload investigation.
- Before `k8s_pods_get`, `k8s_pods_log`, or `k8s_pods_top` to find the
  exact pod name.

## How to invoke

```
use_skill(skill="k8s_pods_list")
use_skill(skill="k8s_pods_list", fieldSelector="status.phase=Running")
use_skill(skill="k8s_pods_list", labelSelector="app=nginx")
use_skill(skill="k8s_pods_list", labelSelector="app=nginx,env=prod")
use_skill(skill="k8s_pods_list", labelSelector="app in (nginx,apache)")
```

## Parameters

| Name | Type | Required | Description |
|---|---|---|---|
| `fieldSelector` | string | no | Filter by pod fields. Supported: `metadata.name`, `metadata.namespace`, `spec.nodeName`, `spec.restartPolicy`, `spec.schedulerName`, `spec.serviceAccountName`, `status.phase` (Pending/Running/Succeeded/Failed/Unknown), `status.podIP`, `status.nominatedNodeName`. Pattern: `^[.\-A-Za-z0-9]+([=!,]{1,2}[./\-A-Za-z0-9]+)+$`. **Note:** CrashLoopBackOff is a container state, NOT a pod phase — you cannot filter by it directly. |
| `labelSelector` | string | no | Standard Kubernetes label selector. Examples: `app=myapp`, `app=myapp,env=prod`, `app in (myapp,yourapp)`, `environment!=dev`. Pattern: `^([/_.\-A-Za-z0-9=, ()!])+$`. |

## What it returns

A table with columns: NAMESPACE, APIVERSION, KIND, NAME, READY, STATUS,
RESTARTS, AGE, IP, NODE, NOMINATED NODE, READINESS GATES, LABELS.

## Common pitfalls

- **Hundreds of pods on a busy cluster** — summarize; do NOT paste the
  full list to the user. Group by namespace or status.
- **`status.phase=Running` includes pods whose containers are
  crash-looping** — the phase is Running but containers keep restarting.
  Check the RESTARTS column.
- **Finding CrashLoopBackOff pods** — filter with
  `fieldSelector=status.phase=Running`, then look at RESTARTS count, or
  use `k8s_events_list` with `fieldSelector=reason=BackOff`.

## Read-only safety

This skill only READS pod metadata. It never modifies the cluster. Safe
to call freely.
