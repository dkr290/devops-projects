---
name: k8s_pods_log
description: Get the logs of a Kubernetes Pod in the current or provided namespace with the provided name. Read-only.
---

# k8s_pods_log

Reads container logs from a Pod. Equivalent to `kubectl logs`. Backed by
the kubernetes-mcp-server `pods_log` tool.

## When to use

- User asks "show logs for pod X", "what's the error in pod Y".
- After `k8s_pods_get` shows a pod with high restart count — call with
  `previous=true` to see why the last container crashed.
- Investigating application errors, stack traces, or unexpected behavior.

## How to invoke

```
use_skill(skill="k8s_pods_log", name="nginx-abc123", namespace="default")
use_skill(skill="k8s_pods_log", name="nginx-abc123", namespace="default",
          tail=200)
use_skill(skill="k8s_pods_log", name="multi-container-pod", namespace="prod",
          container="app")
use_skill(skill="k8s_pods_log", name="crashing-pod", namespace="default",
          previous=true)
```

## Parameters

| Name | Type | Required | Description |
|---|---|---|---|
| `name` | string | **yes** | Exact pod name. Get from `k8s_pods_list` if unsure. |
| `namespace` | string | no | Namespace the pod lives in. Defaults to configured namespace if omitted. |
| `container` | string | no | Specific container name. Required if the pod has multiple containers; otherwise the call may fail or return only the first container's logs. |
| `previous` | boolean | no | If true, returns logs from the PREVIOUS (terminated) container instance. Use this for CrashLoopBackOff debugging. Default false. |
| `tail` | integer | no | Number of lines from the end. Default 100. Use higher values for stack traces; use 0 for all logs (careful — can be huge). |

## What it returns

Plain-text log lines from the container's stdout/stderr.

## Common pitfalls

- **"pod not found"** — wrong name or namespace. Confirm with
  `k8s_pods_list`.
- **"container X not found"** — pod has multiple containers and you
  either specified a non-existent one or the skill picked the wrong
  default. Call `k8s_pods_get` first to see the container names.
- **Empty logs with `previous=true`** — the container never terminated,
  so there's no previous instance. Drop `previous` and call again.
- **Huge output** — never call with `tail=0` on a chatty application.
  Start with the default 100 and increase if needed.
- **Binary or non-UTF8 logs** — may appear garbled. Report this to the
  user instead of trying to interpret.

## Read-only safety

This skill only READS log data. It never executes commands in the
container or modifies the pod. Safe to call freely.
