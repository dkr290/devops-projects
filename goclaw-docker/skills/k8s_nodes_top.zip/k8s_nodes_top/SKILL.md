---
name: k8s_nodes_top
description: List CPU and memory consumption of Kubernetes nodes as recorded by the Kubernetes Metrics Server. Read-only.
---

# k8s_nodes_top

Returns current CPU and memory usage for one or all nodes, sourced from
metrics-server. Equivalent to `kubectl top nodes`. Backed by the
kubernetes-mcp-server `nodes_top` tool.

## When to use

- User asks "which nodes are under pressure", "cluster CPU usage",
  "top nodes", "node resource usage".
- First step in capacity-planning or performance triage.
- Before `k8s_nodes_stats_summary` to identify which node needs a deep
  dive.

## How to invoke

```
use_skill(skill="k8s_nodes_top")                                        # all nodes
use_skill(skill="k8s_nodes_top", name="k3d-eg-operator-agent-0")        # one node
use_skill(skill="k8s_nodes_top", label_selector="node-role.kubernetes.io/worker=")
```

## Parameters

| Name | Type | Required | Description |
|---|---|---|---|
| `name` | string | no | Specific node name. Omit to get all nodes. |
| `label_selector` | string | no | Kubernetes label selector (only used when `name` is omitted). Pattern: `^([/_.\-A-Za-z0-9=, ()!])+$`. |

## What it returns

A table with columns: NAME, CPU(cores), CPU%, MEMORY(bytes), MEMORY%.
CPU is in millicores (e.g. `250m` = 0.25 cores); memory in Mi or Gi.
Percentages are relative to the node's allocatable capacity.

## Common pitfalls

- **Empty result with no error** — metrics-server is not installed,
  not healthy, or hasn't scraped yet. Check with
  `k8s_pods_list_in_namespace(namespace="kube-system", labelSelector="k8s-app=metrics-server")`.
- **Stale data** — metrics-server refreshes every 30–60s. Numbers may
  lag current usage by up to a minute.
- **Only CPU and memory** — for disk, network, or PSI, use
  `k8s_nodes_stats_summary` instead.

## Read-only safety

This skill only READS metrics from metrics-server. It never modifies
the cluster. Safe to call freely.
