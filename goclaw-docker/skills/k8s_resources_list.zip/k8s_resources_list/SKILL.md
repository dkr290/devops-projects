---
name: k8s_resources_list
description: List Kubernetes resources and objects in the current cluster by providing their apiVersion and kind and optionally the namespace and label selector. Works for any resource type. Read-only.
---

# k8s_resources_list

Lists ANY Kubernetes resource type by apiVersion + kind, with optional
namespace and label filtering. This is the universal "list" tool —
use it for resource types that don't have a dedicated skill
(Deployments, Services, Ingresses, ConfigMaps, StatefulSets, DaemonSets,
Jobs, CronJobs, PVs, PVCs, Roles, etc.). Equivalent to
`kubectl get <kind> [-n <namespace>] [-l <selector>]`. Backed by the
kubernetes-mcp-server `resources_list` tool.

## When to use

- User asks "list deployments", "show services in namespace X", "any
  ingresses", "list all configmaps", "show cron jobs".
- First step before `k8s_resources_get` on a specific resource.
- For Pods specifically, prefer `k8s_pods_list` /
  `k8s_pods_list_in_namespace` (slightly more focused output) — but
  `k8s_resources_list` works for Pods too.

## How to invoke

```
use_skill(skill="k8s_resources_list", apiVersion="apps/v1", kind="Deployment")
use_skill(skill="k8s_resources_list", apiVersion="apps/v1", kind="Deployment",
          namespace="production")
use_skill(skill="k8s_resources_list", apiVersion="v1", kind="Service",
          namespace="default")
use_skill(skill="k8s_resources_list", apiVersion="v1", kind="Node")
  # ^ cluster-scoped
use_skill(skill="k8s_resources_list", apiVersion="networking.k8s.io/v1",
          kind="Ingress", labelSelector="app=web")
use_skill(skill="k8s_resources_list", apiVersion="batch/v1", kind="CronJob")
```

## Parameters

| Name | Type | Required | Description |
|---|---|---|---|
| `apiVersion` | string | **yes** | Examples: `v1`, `apps/v1`, `batch/v1`, `networking.k8s.io/v1`, `rbac.authorization.k8s.io/v1`, `storage.k8s.io/v1`. |
| `kind` | string | **yes** | Examples: `Pod`, `Service`, `Deployment`, `StatefulSet`, `DaemonSet`, `ReplicaSet`, `Job`, `CronJob`, `Ingress`, `ConfigMap`, `Secret`, `PersistentVolume`, `PersistentVolumeClaim`, `Namespace`, `Node`, `ServiceAccount`, `Role`, `ClusterRole`, `RoleBinding`, `ClusterRoleBinding`, `StorageClass`. |
| `namespace` | string | no | If omitted, lists across ALL namespaces (for namespaced resources). Omit for cluster-scoped resources. |
| `labelSelector` | string | no | Standard Kubernetes label selector. Pattern: `^([/_.\-A-Za-z0-9=, ()!])+$`. |
| `fieldSelector` | string | no | Field selector (supported fields vary by resource type; for Pods see `k8s_pods_list`). Pattern: `^[.\-A-Za-z0-9]+([=!,]{1,2}[./\-A-Za-z0-9]+)+$`. |

## Common apiVersion + kind pairs

Same table as `k8s_resources_get` — see that skill's documentation.

## What it returns

A table with columns appropriate to the resource type (NAME, NAMESPACE,
READY, STATUS, AGE, plus kind-specific columns like CLUSTER-IP for
Services, SCHEDULE for CronJobs, etc.).

## Common pitfalls

- **"the server doesn't have a resource type"** — wrong apiVersion/kind
  combination, or the CRD isn't installed. Double-check spelling and
  capitalization.
- **Listing Secrets** — the result includes Secret metadata only
  (name, namespace, type, age) in table form. Do NOT follow up with
  `k8s_resources_get` to retrieve secret data unless the user
  explicitly needs it — and even then, never print decoded values.
- **Too many results** — on a busy cluster, listing all ConfigMaps or
  Secrets across all namespaces can return hundreds of rows. Use
  `namespace` and `labelSelector` to narrow.

## Read-only safety

This skill only READS resource metadata. It never modifies the cluster.
Safe to call freely, subject to RBAC.
