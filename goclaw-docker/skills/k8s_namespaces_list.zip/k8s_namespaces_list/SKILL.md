---
name: k8s_namespaces_list
description: List all the Kubernetes namespaces in the current cluster. Read-only.
---

# k8s_namespaces_list

Lists every namespace in the cluster with its status and age. Backed by
the kubernetes-mcp-server `namespaces_list` tool.

## When to use

- User asks "what namespaces exist", "list namespaces", "show all
  namespaces".
- First step when investigating an unfamiliar cluster — gives you the
  high-level layout before drilling into specific namespaces.
- Before calling `k8s_pods_list_in_namespace` or `k8s_resources_list`
  with a `namespace` parameter, to confirm the namespace exists.

## How to invoke

```
use_skill(skill="k8s_namespaces_list")
use_skill(skill="k8s_namespaces_list", fieldSelector="metadata.name=kube-system")
use_skill(skill="k8s_namespaces_list", fieldSelector="status.phase=Active")
```

## Parameters

| Name | Type | Required | Description |
|---|---|---|---|
| `fieldSelector` | string | no | Filter by namespace fields. Supported: `metadata.name`, `status.phase`. Pattern: `^[.\-A-Za-z0-9]+([=!,]{1,2}[./\-A-Za-z0-9]+)+$`. |

## What it returns

A table with columns roughly: NAME, STATUS, AGE, LABELS. Status is
typically `Active` or `Terminating`.

## Common pitfalls

- **Very short list on a managed cluster** — that's normal. Managed
  Kubernetes (EKS, GKE, AKS) often has only 5–10 namespaces by default.
- **Empty result with no error** — rare, but indicates either RBAC
  restrictions or a brand-new cluster.
- **`Terminating` namespaces that never finish** — usually means a
  stuck finalizer on a resource inside the namespace. Investigate with
  `k8s_resources_list` for that namespace.

## Read-only safety

This skill only READS namespace metadata. It never creates, modifies, or
deletes namespaces. Safe to call freely.
