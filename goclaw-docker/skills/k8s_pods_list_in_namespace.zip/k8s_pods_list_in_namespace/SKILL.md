---
name: k8s_pods_list_in_namespace
description: List all the Kubernetes pods in the specified namespace in the current cluster. Read-only.
---

# k8s_pods_list_in_namespace

Lists Pods in a single namespace. Equivalent to
`kubectl get pods -n <namespace>`. Backed by the kubernetes-mcp-server
`pods_list_in_namespace` tool.

## When to use

- User asks "list pods in namespace X", "what's running in production".
- After `k8s_namespaces_list` identifies the namespace you care about.
- When `k8s_pods_list` returns too many results and you want to focus
  on one namespace.

## How to invoke

```
use_skill(skill="k8s_pods_list_in_namespace", namespace="kube-system")
use_skill(skill="k8s_pods_list_in_namespace", namespace="production",
          fieldSelector="status.phase=Running")
use_skill(skill="k8s_pods_list_in_namespace", namespace="production",
          labelSelector="app=web")
```

## Parameters

| Name | Type | Required | Description |
|---|---|---|---|
| `namespace` | string | **yes** | The namespace to list pods from. Must exist — use `k8s_namespaces_list` to confirm. |
| `fieldSelector` | string | no | Same supported fields as `k8s_pods_list`. Pattern: `^[.\-A-Za-z0-9]+([=!,]{1,2}[./\-A-Za-z0-9]+)+$`. |
| `labelSelector` | string | no | Standard Kubernetes label selector. Pattern: `^([/_.\-A-Za-z0-9=, ()!])+$`. |

## What it returns

Same table format as `k8s_pods_list`: NAMESPACE, APIVERSION, KIND, NAME,
READY, STATUS, RESTARTS, AGE, IP, NODE, etc.

## Common pitfalls

- **"namespace not found"** — typo or the namespace was deleted.
  Confirm with `k8s_namespaces_list`.
- **Empty result** — namespace exists but has no pods. Normal for
  system-reserved namespaces like `kube-node-lease`.
- **Always prefer this over `k8s_pods_list` when the namespace is
  known** — it's faster and returns less data.

## Read-only safety

This skill only READS pod metadata. It never modifies the cluster. Safe
to call freely.
