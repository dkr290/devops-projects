---
name: k8s_resources_get
description: Get a Kubernetes resource in the current cluster by providing its apiVersion, kind, optionally the namespace, and its name. Works for any resource type — Deployment, Service, Ingress, ConfigMap, StatefulSet, DaemonSet, Job, CronJob, PV, PVC, etc. Read-only.
---

# k8s_resources_get

Fetches detailed information about ANY Kubernetes resource by
apiVersion + kind + name. This is the universal "get" tool — use it for
resource types that don't have a dedicated skill (Deployments, Services,
Ingresses, ConfigMaps, StatefulSets, DaemonSets, Jobs, CronJobs, PVs,
PVCs, Roles, ClusterRoles, etc.). Equivalent to
`kubectl get <kind> <name> -n <namespace> -o yaml`. Backed by the
kubernetes-mcp-server `resources_get` tool.

## When to use

- User asks about a specific Deployment, Service, Ingress, ConfigMap,
  or any resource type other than Pod/Node/Namespace.
- After `k8s_resources_list` identifies the resource you want to
  inspect.
- For Pods specifically, prefer `k8s_pods_get` (slightly more focused
  output) — but `k8s_resources_get` works for Pods too.

## How to invoke

```
use_skill(skill="k8s_resources_get", apiVersion="apps/v1",
          kind="Deployment", name="web", namespace="production")
use_skill(skill="k8s_resources_get", apiVersion="v1",
          kind="Service", name="kubernetes", namespace="default")
use_skill(skill="k8s_resources_get", apiVersion="v1",
          kind="Node", name="k3d-eg-operator-agent-0")
  # ^ cluster-scoped, no namespace needed
use_skill(skill="k8s_resources_get", apiVersion="networking.k8s.io/v1",
          kind="Ingress", name="web-ingress", namespace="production")
```

## Parameters

| Name | Type | Required | Description |
|---|---|---|---|
| `apiVersion` | string | **yes** | Examples: `v1`, `apps/v1`, `batch/v1`, `networking.k8s.io/v1`, `rbac.authorization.k8s.io/v1`, `storage.k8s.io/v1`, `route.openshift.io/v1`. |
| `kind` | string | **yes** | Examples: `Pod`, `Service`, `Deployment`, `StatefulSet`, `DaemonSet`, `ReplicaSet`, `Job`, `CronJob`, `Ingress`, `ConfigMap`, `Secret`, `PersistentVolume`, `PersistentVolumeClaim`, `Namespace`, `Node`, `ServiceAccount`, `Role`, `ClusterRole`, `RoleBinding`, `ClusterRoleBinding`, `StorageClass`, `Route` (OpenShift). |
| `name` | string | **yes** | Exact resource name. |
| `namespace` | string | no | Namespace for namespaced resources. **Omit for cluster-scoped resources** (Node, Namespace, PersistentVolume, ClusterRole, ClusterRoleBinding, StorageClass). If omitted for a namespaced resource, uses the configured default. |

## Common apiVersion + kind pairs

| apiVersion | kind | Scope |
|---|---|---|
| `v1` | Pod, Service, ConfigMap, Secret, PersistentVolumeClaim, ServiceAccount | namespaced |
| `v1` | Node, Namespace, PersistentVolume | cluster |
| `apps/v1` | Deployment, StatefulSet, DaemonSet, ReplicaSet | namespaced |
| `batch/v1` | Job | namespaced |
| `batch/v1` | CronJob | namespaced |
| `networking.k8s.io/v1` | Ingress, NetworkPolicy | namespaced |
| `rbac.authorization.k8s.io/v1` | Role, RoleBinding | namespaced |
| `rbac.authorization.k8s.io/v1` | ClusterRole, ClusterRoleBinding | cluster |
| `storage.k8s.io/v1` | StorageClass | cluster |
| `route.openshift.io/v1` | Route | namespaced (OpenShift) |

## What it returns

The full resource object as YAML/JSON: metadata, spec, and (for most
resources) status.

## Common pitfalls

- **"the server doesn't have a resource type"** — wrong apiVersion or
  kind combination. Check the table above or use `k8s_resources_list`
  with what you believe is correct and see if it errors.
- **Namespace on cluster-scoped resource** — the parameter is ignored
  for cluster-scoped resources, but omitting it is cleaner.
- **Secrets** — this skill WILL return Secret objects including the
  base64-encoded `data` field. Per the observer role, NEVER decode or
  print those values. Report only the secret's name, namespace, type,
  and keys.

## Read-only safety

This skill only READS resource state. It never modifies the cluster.
Safe to call freely, subject to RBAC.
