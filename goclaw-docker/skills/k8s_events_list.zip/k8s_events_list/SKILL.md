---
name: k8s_events_list
description: List Kubernetes events (warnings, errors, state changes) for debugging and troubleshooting in the current cluster from all namespaces. Read-only.
---

# k8s_events_list

List Kubernetes events (warnings, errors, state changes) for debugging and
troubleshooting. Backed by the kubernetes-mcp-server `events_list` tool.

## When to use

- User reports a problem with a workload ("my pod keeps restarting",
  "deployment stuck", "service not reachable") — call this FIRST before
  deeper investigation.
- User asks "what happened", "show events", "any warnings", "why did X fail".
- After calling `k8s_resources_get` on an unhealthy resource, pull events
  for the same namespace to find the cause.
- Periodic cluster-health reviews.

## How to invoke

```
use_skill(skill="k8s_events_list")
use_skill(skill="k8s_events_list", namespace="production")
use_skill(skill="k8s_events_list", fieldSelector="type=Warning")
use_skill(skill="k8s_events_list",
          fieldSelector="involvedObject.name=my-pod-abc123")
```

## Parameters

| Name | Type | Required | Description |
|---|---|---|---|
| `namespace` | string | no | If omitted, lists events across ALL namespaces. Set this to focus on one namespace. |
| `fieldSelector` | string | no | Kubernetes field selector. Supported fields: `involvedObject.kind`, `involvedObject.name`, `involvedObject.namespace`, `involvedObject.uid`, `involvedObject.apiVersion`, `involvedObject.resourceVersion`, `involvedObject.fieldPath`, `reason`, `reportingComponent`, `source`, `type`. Pattern: `^[.\-A-Za-z0-9]+([=!,]{1,2}[./\-A-Za-z0-9]+)+$`. |

Common field selectors:
- `type=Warning` — only warnings (most useful for triage)
- `type=Normal` — only informational events
- `reason=FailedScheduling` — only pod scheduling failures
- `reason=BackOff` — only container restart backoffs
- `involvedObject.kind=Pod` — only pod-related events
- `involvedObject.name=<pod-name>` — events for one specific pod

## What it returns

A table of events with columns roughly: NAMESPACE, LAST SEEN, TYPE, REASON,
OBJECT, MESSAGE. Newest events typically appear last; sort client-side if
you need a different order.

## Common pitfalls

- **No `type=Warning` filter** — the default output mixes Normal and
  Warning events. For triage, always filter to `type=Warning` first.
- **Too many events** — busy clusters can have thousands. Use
  `fieldSelector` or `namespace` to narrow down before calling.
- **Empty result** — events expire after ~1 hour by default. An empty
  list does NOT mean nothing happened; it may mean the events aged out.
- **`involvedObject.name` requires exact match** — use `k8s_pods_list`
  first to find the exact pod name if unsure.

## Read-only safety

This skill only READS event data from the Kubernetes API. It never
creates, modifies, or deletes anything. Safe to call freely.
